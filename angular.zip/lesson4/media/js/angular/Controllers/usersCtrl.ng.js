ContactListApp.controller("usersCtrl",['$scope','$filter','$http',function($scope,$filter,$http){

}]);
