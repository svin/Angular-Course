<?php
//populate the $_SESSION
session_start();

var_dump($_SESSION['auth']);