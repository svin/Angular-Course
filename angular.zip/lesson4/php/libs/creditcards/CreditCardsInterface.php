<?php
/**
 * Created by PhpStorm.
 * User: Jbt
 * Date: 5/18/2016
 * Time: 4:35 AM
 */

namespace creditcards;


interface CreditCardsInterface
{
    function doA();
    function doB();
}