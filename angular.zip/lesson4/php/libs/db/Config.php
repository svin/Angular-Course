<?php
/**
 * Created by PhpStorm.
 * User: Jbt
 * Date: 5/11/2016
 * Time: 5:54 AM
 */

namespace db;


class Config{
    const HOST = "localhost";
    const USER = "root";
    const PASS = "";
    const SCHEMA = "company";
}