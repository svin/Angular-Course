<?php

/**
 * Created by PhpStorm.
 * User: Jbt
 * Date: 5/22/2016
 * Time: 7:30 PM
 */
class Employees
{
    // implement RESTFUL 
}